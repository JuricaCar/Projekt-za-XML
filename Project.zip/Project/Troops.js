const TroopsData = [
    {
        name: "Barbarian King",
        photo: "images/barbarianking.jpg",
        desc: "The Barbarian King is the toughest and meanest barbarian in the realm, whose apetite for Dark Eliksir has caused him to grow even bigger than giants. He can attack but also can defend your village."
    },
    {
        name: "Archer Queen",
        photo: "images/archerqueen.png",
        desc: "The Archer Queen is an eagle-eyed warrior, whose weapon is modified x-bow. She can attack enemy villages and defend yours."
    },
    {
        name: "Grand Warden",
        photo: "images/grandwarden.jpg",
        desc: "The Grand Warden is a brilliant tactician who has spent years learning how to heal multiple troops at once. He can make all troops invncible for few seconds in his range."
    },
    {
        name: "Barbarian",
        photo: "images/barbarian.jpg",
        desc: "This fearless warrior relies on his bulging muscles and stiking mustache to weak havoc in enemy villages. Release a horde of Barbarians and enjoy the mayhem!"
    },
    {
        name: "Archer",
        photo: "images/archer.jpg",
        desc: "These sharpshooters like to keep their distance on the battlefield and in life. Nothing makes them happier than single-mindedly taking down their target."
    },
    {
        name: "Giant",
        photo: "images/giant.jpg",
        desc: "These big guys may seem calm, but show them enemy defences and you'll see their fury unleashed! They are slow but they know how to tank a lot of damage."
    },
    {
        name: "Goblin",
        photo: "images/goblin.jpg",
        desc: "This greedy little creatures have eyes only for one thing. LOOT! They are faster than wind but they hitpoints are low."
    },
    {
        name: "Wall Breaker",
        photo: "images/wallbreaker.jpg",
        desc: "Nothing warms a Wall Breaker's cold heart like blowing up walls. A squad of them will make nice path through walls for other troops and they will do it with a BANG!"
    },
    {
        name: "Balloon",
        photo: "images/balloon.jpg",
        desc: "Skeletons who were promoted are now throwing bombs from balloons! They have traded their joy of destroying walls for pleasure of destroying defences."
    },
    {
        name: "Wizard",
        photo: "images/wizard.jpg",
        desc: "Wizards are fireball throwing fear of the battlefield. They can destroy anything, on land or sky!"
    },
    {
        name: "Healer",
        photo: "images/healer.jpg",
        desc: "This majestic creature lives to protect and heal friendly troops. Any army is improved with her healing assistence but make sure to protect her from air defences."
    },
    {
        name: "Dragon",
        photo: "images/dragon.jpg",
        desc: "The might of the dragons is known throughout the land. This scary terror of the skies feels no mercy and nothing will escape from their fire breath."
    },
    {
        name: "P.E.K.K.A",
        photo: "images/pekka.jpg",
        desc: "The greatest mistery of Clash of Clans. Is it a knight? A samurai? A robot? No one knows! All we do know is her armor protects heavy damage."
    },
    {
        name: "Baby Dragon",
        photo: "images/babydragon.jpg",
        desc: "This fire-breathing is shy around air units but don't get fooled. When there are no air units around, it becomes enraged, gaining speed and damage."
    },
    {
        name: "Miner",
        photo: "images/miner.png",
        desc: "These sneaky shovelers burrow underground, passing beneath walls and traps to pop right next to their targets! They cannot be damaged while underground."
    },
    {
        name: "Electro Dragon",
        photo: "images/electrodragon.jpg",
        desc: "Possesing iron-tough scales and a breath of devastating lightning, the Electro Dragon's favourite thing is raining destruction from above. When he dies, he pummels the ground with lightning strikes!"
    },
    {
        name: "Minion",
        photo: "images/minion.jpg",
        desc: "This ugly looking sky troops born out of Dark Eliksir are undetectable by the air seeking mines. Their damage is decent, but they are fragile."
    },
    {
        name: "Hog Rider",
        photo: "images/hogrider.jpg",
        desc: "Hog Rider punishes all who hide behind their walls by jumping over them with their crazy hogs! Fueled with Dark Eliksir, these warriors have never known defeat!"
    },
    {
        name: "Valkyrie",
        photo: "images/valkyrie.jpg",
        desc: "A master of the two-handed axe, this glorious warrior runs between nearby buildings and can shred several troops or buildings at once with her whirlwind blow!"
    },
    {
        name: "Golem",
        photo: "images/golem.jpg",
        desc: "This mighty rocky creatures love to soak up damage! When destroyed, it explodes and splits in two little golemites."
    },
    {
        name: "Witch",
        photo: "images/witch.jpg",
        desc: "The Witch never fights alone, she is constantly rising dead warriors from the past battles to lead her attacks."
    },
    {
        name: "Lava Hound",
        photo: "images/lavahound.jpg",
        desc: "This fiery beasts can't resist hunting air defences, providing excelent protection for all other air troops. Once destroyed, they erupt into many little lava pups."
    },
    {
        name: "Bowler",
        photo: "images/bowler.jpg",
        desc: "This blue creature targets everything. He is throwing rocks that can bounce from one to another target, dealing additional damage."
    }

  ];
  
  
  function TroopsTemplate(troop) {
    return `
      <div class="first">
      <h2 class="pet-name">${troop.name}</h2>
      <p>${troop.desc}</p>
      </div>
      <div class="second">
      <img src="${troop.photo}">
      </div>
    `;
  }
  
  document.getElementById("json").innerHTML = `
    ${TroopsData.map(TroopsTemplate).join("")}
  `;
  